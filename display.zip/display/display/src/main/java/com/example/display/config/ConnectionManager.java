package com.example.display.config;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.example.display.model.UserDBBean;

public class ConnectionManager {

	UserDBBean userDB;

	public UserDBBean getUserDB() {
		return userDB;
	}

	public void setUserDB(UserDBBean user) {
		this.userDB = user;
	}
	
	public void setDriver() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Connection connDBase() throws IOException {
		
		Connection conn = null;
		String URL = "jdbc:sqlserver://AUXDEV-DB;databaseName=InterviewDB2";
		String user = "guest";
		String pass = "Gu3st!1234";
		
		try {
			conn = DriverManager.getConnection(URL, user, pass);
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return conn;
		
	}
	
	
}
