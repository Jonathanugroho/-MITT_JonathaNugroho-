package com.example.display.model;

import java.sql.Date;

public class TbKendaraanBean {
	private String BatchOrder;
	private String NoKontrak;
	private String NamaDebitur;
	private String Company;
	private String KodeCabang;
	private String DOBDebitur;
	private String TempatLahir;
	private String NIK;
	private String Alamat;
	private Double OTR;
	private String ObjBrand;
	private String ObjModel;
	private String ObjDesc;
	private Integer Tahun;
	private String Warna;
	private String NoRangka;
	private String NoMesin;
	private String NoPol;
	private String Column1;
	private String Column2;
	private String Column3;
	private String NamaBPKP;
	private String Column4;
	private String Column5;
	private String Pertanggungan;
	private String Column6;
	private String PeriodeAwal;
	private String PeriodeAkhir;
	private String Column7;
	private String NoPolis;
	private Double Premi;
	public String getBatchOrder() {
		return BatchOrder;
	}
	public void setBatchOrder(String batchOrder) {
		BatchOrder = batchOrder;
	}
	public String getNoKontrak() {
		return NoKontrak;
	}
	public void setNoKontrak(String noKontrak) {
		NoKontrak = noKontrak;
	}
	public String getNamaDebitur() {
		return NamaDebitur;
	}
	public void setNamaDebitur(String namaDebitur) {
		NamaDebitur = namaDebitur;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getKodeCabang() {
		return KodeCabang;
	}
	public void setKodeCabang(String kodeCabang) {
		KodeCabang = kodeCabang;
	}
	public String getDOBDebitur() {
		return DOBDebitur;
	}
	public void setDOBDebitur(String dOBDebitur) {
		DOBDebitur = dOBDebitur;
	}
	public String getTempatLahir() {
		return TempatLahir;
	}
	public void setTempatLahir(String tempatLahir) {
		TempatLahir = tempatLahir;
	}
	public String getNIK() {
		return NIK;
	}
	public void setNIK(String nIK) {
		NIK = nIK;
	}
	public String getAlamat() {
		return Alamat;
	}
	public void setAlamat(String alamat) {
		Alamat = alamat;
	}
	public Double getOTR() {
		return OTR;
	}
	public void setOTR(Double oTR) {
		OTR = oTR;
	}
	public String getObjBrand() {
		return ObjBrand;
	}
	public void setObjBrand(String objBrand) {
		ObjBrand = objBrand;
	}
	public String getObjModel() {
		return ObjModel;
	}
	public void setObjModel(String objModel) {
		ObjModel = objModel;
	}
	public String getObjDesc() {
		return ObjDesc;
	}
	public void setObjDesc(String objDesc) {
		ObjDesc = objDesc;
	}
	public Integer getTahun() {
		return Tahun;
	}
	public void setTahun(Integer tahun) {
		Tahun = tahun;
	}
	public String getWarna() {
		return Warna;
	}
	public void setWarna(String warna) {
		Warna = warna;
	}
	public String getNoRangka() {
		return NoRangka;
	}
	public void setNoRangka(String noRangka) {
		NoRangka = noRangka;
	}
	public String getNoMesin() {
		return NoMesin;
	}
	public void setNoMesin(String noMesin) {
		NoMesin = noMesin;
	}
	public String getNoPol() {
		return NoPol;
	}
	public void setNoPol(String noPol) {
		NoPol = noPol;
	}
	public String getColumn1() {
		return Column1;
	}
	public void setColumn1(String column1) {
		Column1 = column1;
	}
	public String getColumn2() {
		return Column2;
	}
	public void setColumn2(String column2) {
		Column2 = column2;
	}
	public String getColumn3() {
		return Column3;
	}
	public void setColumn3(String column3) {
		Column3 = column3;
	}
	public String getNamaBPKP() {
		return NamaBPKP;
	}
	public void setNamaBPKP(String namaBPKP) {
		NamaBPKP = namaBPKP;
	}
	public String getColumn4() {
		return Column4;
	}
	public void setColumn4(String column4) {
		Column4 = column4;
	}
	public String getColumn5() {
		return Column5;
	}
	public void setColumn5(String column5) {
		Column5 = column5;
	}
	public String getPertanggungan() {
		return Pertanggungan;
	}
	public void setPertanggungan(String pertanggungan) {
		Pertanggungan = pertanggungan;
	}
	public String getColumn6() {
		return Column6;
	}
	public void setColumn6(String column6) {
		Column6 = column6;
	}
	public String getPeriodeAwal() {
		return PeriodeAwal;
	}
	public void setPeriodeAwal(String periodeAwal) {
		PeriodeAwal = periodeAwal;
	}
	public String getPeriodeAkhir() {
		return PeriodeAkhir;
	}
	public void setPeriodeAkhir(String periodeAkhir) {
		PeriodeAkhir = periodeAkhir;
	}
	public String getColumn7() {
		return Column7;
	}
	public void setColumn7(String column7) {
		Column7 = column7;
	}
	public String getNoPolis() {
		return NoPolis;
	}
	public void setNoPolis(String noPolis) {
		NoPolis = noPolis;
	}
	public Double getPremi() {
		return Premi;
	}
	public void setPremi(Double premi) {
		Premi = premi;
	}
	
	
}
