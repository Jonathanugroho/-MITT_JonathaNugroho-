package com.example.display;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import com.example.display.model.TbKendaraanBean;

import java.io.FileReader;

public class app {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File file = new File("C:\\Users\\tbauser4\\Desktop\\JO\\soal interview\\testfile.txt");
		FileReader fr = new FileReader(file);
		BufferedReader br =  new BufferedReader(fr);
		
		TbKendaraanBean tbKendaraan = new TbKendaraanBean();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
		
		String line = null;
		line = br.readLine();
		
		while ((line = br.readLine()) != null)
		{
			Integer i  = 0;
			System.out.println(line);
			String [] temp = line.split("\\;");
			System.out.println(Arrays.toString(temp));
			List<String> list = Arrays.asList(temp);
			
			
				tbKendaraan.setBatchOrder(list.get(0));
				tbKendaraan.setNoKontrak(list.get(1));
				tbKendaraan.setNamaDebitur(list.get(2));
				tbKendaraan.setCompany(list.get(3));
				tbKendaraan.setKodeCabang(list.get(4));
				tbKendaraan.setDOBDebitur(sdf.format(list.get(5)));
				tbKendaraan.setTempatLahir(list.get(6));
				tbKendaraan.setNIK(list.get(7));
				tbKendaraan.setAlamat(list.get(8));
				tbKendaraan.setOTR(Double.parseDouble(list.get(9)));
				tbKendaraan.setObjBrand(list.get(10));
				tbKendaraan.setObjModel(list.get(11));
				tbKendaraan.setObjDesc(list.get(12));
				tbKendaraan.setTahun(Integer.parseInt(list.get(13)));
				tbKendaraan.setWarna(list.get(14));
				tbKendaraan.setNoRangka(list.get(15));
				tbKendaraan.setNoMesin(list.get(16));
				tbKendaraan.setNoPol(list.get(17));
				tbKendaraan.setColumn1(list.get(18));
				tbKendaraan.setColumn2(list.get(19));
				tbKendaraan.setColumn3(list.get(20));
				tbKendaraan.setNamaBPKP(list.get(21));
				tbKendaraan.setColumn4(list.get(22));
				tbKendaraan.setColumn5(list.get(23));
				tbKendaraan.setPertanggungan(list.get(24));
				tbKendaraan.setColumn6(list.get(25));
				tbKendaraan.setPeriodeAwal(sdf.format(list.get(26)));
				tbKendaraan.setPeriodeAkhir(sdf.format(list.get(27)));
				tbKendaraan.setColumn7(list.get(28));
				tbKendaraan.setNoPolis(list.get(29));
				tbKendaraan.setPremi(Double.parseDouble(list.get(30)));


		}

	}

}
